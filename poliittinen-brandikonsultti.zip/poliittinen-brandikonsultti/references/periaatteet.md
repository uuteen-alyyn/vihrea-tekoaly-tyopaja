# Periaatteet — brändin rakentaminen poliittisessa kampanjassa

Tämä on menetelmän tietopohja: miksi brändi toimii ja miten se rakennetaan,
kehitetään ja arvioidaan. Kaikki on muotoiltu yleisellä tasolla. Jos jokin
periaate kaipaa esimerkkiä, muotoile siitä yleistettävä ilmiö — älä nojaa
yksittäiseen nimeen, lukuun tai tapaukseen.

## Sisällys

1. Peruskäsitteet — brändi vs. brändäys, miten brändi syntyy
2. Ihmismieli — miksi brändi toimii (tunne, oivallus, muistiankkuri, ensimmäinen tarina)
3. Rakentamisen prosessi — ydin → arvolupaus → yleisö → erottautuminen → viesti → lupaus
4. Kohdeyleisö ja heimo — demografia vs. heimo, pyllistys, prosenttiosuus
5. Erottautuminen ja positiointi — luo markkina, pysy ytimessä, todellinen kilpailija
6. Arvot, aitous ja uskottavuus — arvot kompassina, aitoustesti
7. Ilme — visuaaliset rakennuspalikat (nelikenttä, värit, typografia, tyhjä tila)
8. Ääni — verbaaliset rakennuspalikat (arkkityypit, kolmen sääntö)
9. Dimensiot ja panostuksen järjestys — aloitusviisikko, perusakselit, brändikirja
10. Viesti, budjetti ja pääoma — näkyvyys, pääoman rakentaminen
11. Luova prosessi — häpeän poisto, ideointi, nolous signaalina
12. Yleisimmät virheet

---

## 1. Peruskäsitteet

### Brändi vs. brändäys
- **Brändi** = tunne, mielikuva ja maine, joka äänestäjälle syntyy. Se ei ole
  sinun hallinnassasi — *vastaanottaja* päättää mikä brändisi on. Voit vaikuttaa
  siihen, et omistaa sitä.
- **Brändäys** = keinot, joilla brändi jää mieleen (nimi, tunnus, värit, slogan,
  äänensävy). Ne ovat työkaluja muistijäljen ja tunteen synnyttämiseen, eivät
  itsetarkoitus.
- **Ydinsääntö:** kun kaikki työkalut riisutaan pois, jäljelle jää tunne ja siitä
  syntyvä maine. Se on tärkein. Työkaluja tarvitaan yhä enemmän mitä isommaksi
  kampanja kasvaa — ei heti alussa.

### Miten brändi syntyy
Heität mielikuvia maailmaan → vastaanottajalle syntyy tunne → tunne synnyttää
muistiankkurin (koska se poikkeaa arjen harmaasta virrasta) → kun usean ihmisen
tunteet yhdistyvät, syntyy maine → maine kulkee ihmiseltä toiselle. **Se on
brändi.**

---

## 2. Ihmismieli — miksi brändi toimii

- **Päätös syntyy tunteella, sekunnin murto-osassa.** Se perustellaan järjellä
  vasta jälkikäteen. Jälkikäteinen järkilista ei muuta jo tehtyä päätöstä.
- **Aivot eivät ole muuttuneet.** Teemme yhä samat nopeat, tunnepohjaiset
  selviytymispäätökset (ystävä vai vihollinen). Vain tapa käyttää aivoja on
  muuttunut. Ensivaikutelma on väistämätön ja ohjaava.
- **Oivalluksen voima.** Jos kerrot asian valmiina, se menee ohi. Jos johdatat
  ihmisen oivaltamaan sen itse, syntyy vahva muistiankkuri. → Kysy, kuuntele,
  anna vastaanottajan tehdä johtopäätös.
- **Muistiankkuri syntyy poikkeamasta.** Tunne syntyy aina kun jokin erottuu
  tasaisesta virrasta. Tavoite on herättää tunne, ei välittää tietoa.
- **Ensimmäisen tarinan voima.** Kun uskomme jotain ensimmäistä kertaa, haemme
  sen jälkeen vain sitä tukevaa tietoa ja sivuutamme muun. Framen omistaminen
  ensin on ratkaisevaa.
- **Vain käytetty tieto pysyy.** "Olen kuullut tämän ennenkin" ei ole
  ymmärtämistä. Toisto on välttämätöntä ennen kuin viesti muuttuu toiminnaksi.
  Mitä ilmeisempi viisaus, sitä huonommin sitä käytetään.
- **Intuitio ei ole hötöä.** Se on kokemusten ja oppien summa, joka aktivoituu
  juuri siinä nopeassa päätöksessä.

---

## 3. Rakentamisen prosessi (tunne → järki → tunne)

Rakennusjärjestys on tärkeä: **ydin ensin, työkalut vasta myöhemmin.**

1. **Ydin ("miksi").** Miksi tämä ehdokas/liike on olemassa? Miksi joku jaksaisi
   herätä aamulla sen puolesta? Kaiva ohjelmasisällön alta syvempi syy. Testi:
   onko se kristallinkirkas, ja osaako jokainen kampanjassa sanoa sen samalla
   tavalla?
2. **Arvolupaus.** Ytimen järkeen vetoava, hyötyperusteinen versio: mitä
   konkreettista vastaanottaja saa. Tunne vetää puoleensa, arvolupaus antaa
   perustelun, jolla valinnan voi oikeuttaa itselleen.
3. **Yleisön analyysi.** Keitä jo kuuntelevat? Keitä he ovat maailmankatsomuk-
   seltaan? Voisiko heitä olla enemmän menettämättä ydintä?
4. **Erottautuminen.** Mikä tekee juuri tästä toimijasta ainutlaatuisen niiden
   joukossa, jotka lupaavat samaa?
5. **Viesti ja toisto.** Kun ydin ja erottautuminen ovat selvillä, tiedät mitä
   viestiä toistat. Sama ydin saa eri muodon eri kanavissa; punainen lanka
   säilyy.
6. **Lupaus ja lunastus.** Mitä lupaat, ja lunastuuko se jatkuvasti? Lunastuksen
   ratkaisee vastaanottaja: "juuri mitä lupasivat — piti paikkansa."

---

## 4. Kohdeyleisö ja heimo

**Heimo on joukko ihmisiä, joita yhdistää sama maailmankuva, arvot ja
identiteetti — ei ikä, sukupuoli, tulot tai asuinpaikka.** Koska he katsovat
maailmaa samalla tavalla, he myös reagoivat samaan viestiin samalla tavalla ja
kokevat sen "juuri minulle tehdyksi". Heimo on brändin todellinen kohde.

- **Demografia ei ole heimo.** Demografia kuvaa millainen ihminen on
  *ulkoisesti* ("35-vuotias kaupunkilainen nainen"); heimo kuvaa *miten hän
  ajattelee ja mihin hän samastuu*. Ulkoiset piirteet eivät ennusta ajattelua:
  - Sama demografia, eri heimot: kaksi samanikäistä kaupunkilaista voi olla
    arvomaailmaltaan täysin vastakkaisia.
  - Eri demografia, sama heimo: 25- ja 70-vuotias voivat kuulua samaan heimoon,
    jos heitä yhdistää sama arvopohja.
- **Miksi heimo ratkaisee.** Vahva brändi syntyy vain puhuttelemalla heimoa,
  koska vain jaettu maailmankuva saa ihmisen aktivoitumaan — äänestämään,
  jakamaan, puolustamaan. Demografialle puhuminen ei aktivoi ketään: sama viesti
  pitäisi saada sopimaan keskenään erimielisille ihmisille, jolloin se vesittyy.
- **Miten heimo tunnistetaan.** Kysy, mikä maailmankatsomus, arvo tai jaettu
  kokemus ihmisiä yhdistää — ei mikä ikä tai alue. Tarkenna: mikä tunne saa
  heidät liikkeelle, minkä puolesta he ovat, mitä vastaan.
- **Kohde ei voi olla "kaikki".** Silloin viesti vesittyy — se ei ole kenenkään.
- **Uskalla pyllistää.** Kun kumarrat jollekin, käännät selkäsi jollekin
  toiselle. Joko seisot jonkin puolesta tai jäät näkymättömäksi. Vastustuksen
  syntyminen on merkki siitä, että viesti osuu heimoon.
- **Prosenttiosuus-menetelmä.** Päätä tavoiteltu kannatusosuus. Sillä osuudella,
  jota et tavoittele, ei ole väliä. Puhu, kuuntele ja kysy niiltä, joita
  tavoittelet → he kokevat "tämä on juuri minua varten" → syntyy lojaliteetti.
  Jos yrität puhua kaikille, ydinyleisö kokee "ei tämä olekaan minun".
- **Tunne kohteesi syvältä.** Elämänkatsomus, arvot, huolet, kiinnostukset —
  mitä syvemmältä tunnet, sitä paremmin tavoitat. Liian suurta massaa
  tavoitellessa yhtenevät tekijät katoavat.
- **Yleisö ei aina tiedä mitä haluaa.** Kuuntele, mutta osaa erottaa relevantti
  toive siitä, mikä auttaa heitä enemmän kuin he osaavat pyytää. Sinun on itse
  uskottava siihen mitä teet — enemmistö sanoo "ei toimi". Älä silti ylenkatso
  kenenkään ajattelutapaa.

---

## 5. Erottautuminen ja positiointi

- **Luo markkina, älä kilpaile olemassa olevasta.** Vahvin asema syntyy, kun
  asetat keskustelun omilla ehdoillasi sen sijaan että taistelet vastustajan
  valitsemasta aiheesta hänen kentällään. Agendan omistaja voittaa.
- **Pysy ytimessä.** Jatkuva uudistautuminen ja viestin hajautus on
  itsevarmuuden puutetta — luota ytimeen. Vauhtisokeus (aletaan puhua siitä,
  mikä tänään sattuu kiinnostamaan) hukuttaa ytimen.
- **Puhu vastaanottajasta, älä itsestäsi.** Kun puhut äänestäjästä, hän
  kuuntelee. Kun puhut omista ansioistasi, hän ei. Vastaanottaja on sankari —
  käännä viesti siihen mitä hyötyä siitä on hänelle.
- **Tunnista todellinen kilpailija.** Se ei aina ole ilmeisin vastustaja.
  Todellinen kilpailija voi olla välinpitämättömyys, epäusko tai äänestämättä
  jättäminen. Positiointi suhteessa oikeaan kilpailijaan määrää konkreettiset
  ratkaisut.
- **Tee se mitä ei ole.** Vahvin erottautuminen on jotain, mitä ei vielä ole
  olemassa. Parhaat ideat ovat usein ilmiselviä — mutteivät kuulostaneet
  hyvältä ensi kerralla.

---

## 6. Arvot, aitous ja uskottavuus

- **Arvot ovat kompassi, eivät julistus.** Brändirakennuksessa viesti ohjaa
  kaikkea tekemistä. Arvot ovat valintakriteeri: kun eteen tulee mahdollisuus,
  joka on ristiriidassa ytimen kanssa, siitä kieltäydytään — vaikka se maksaisi.
- **Aitous — totuuden perä.** Vahvaa brändiä ei voi rakentaa tyhjän päälle;
  tarvitaan todellinen ydin, jonka lupaus lunastuu. Ilman sitä viesti romahtaa
  ensimmäisessä testissä (esim. haastattelussa tai paineessa).
- **Aitoustesti (vrt. "viherpesu").** Onko sanoma rakennettu **aidosti mission
  pohjalta**, vai onko se **jälkikäteinen kuori**, jolla puolustellaan
  toimintaa, joka ei sitä tue?
  - Mission pitää johtaa tekoihin. ✅
  - Valmis toiminta + jälkeenpäin liimattu arvoviesti = uskottavuusriski. ❌
  - Ristiriita sanoman ja tekojen välillä paljastuu ja kääntyy itseään vastaan.
- **Kaksi pätevää lähtökohtaa.** Vahva brändi voi syntyä joko aidosta
  arvopohjasta tai puhtaasta pyrkimyksestä — kunhan et toimi itseäsi vastaan.
  Ristiriita oman arvomaailman kanssa näkyy ulos ja rapauttaa uskottavuuden.
- **Vahvin paketti:** kun ydin, osaaminen, hyöty ja aito arvopäämäärä yhdistyvät,
  viesti on horjumaton, koska se ei ole esitystä.

---

## 7. Ilme — visuaaliset rakennuspalikat

Työkaluja, joilla mielikuvaa ohjataan. Käytä kun perusta (ydin, heimo, viesti)
on jo mietitty. Visuaalinen ilme on yksi vahvimmista mielikuvan rakentajista.

- **Johdonmukaisuus rakentaa luottamusta.** Valitse tyyli/rooli ja pysy siinä.
  Yhtäkkinen tyylin vaihdos rapauttaa luottamuksen ("ei tämä olekaan mitä
  luulin").
- **Mielikuvan ja todellisuuden on täsmättävä (nelikenttä).** Ilme voi *näyttää*
  arvokkaalta tai vaatimattomalta, ja toimija voi *olla* sitä tai ei — neljä
  yhdistelmää ovat kaikki päteviä tietoisia strategioita. Vaara on **ristiriita**:
  jos näytät yhtä ja olet toista, syntyy "minua huijattiin" -tunne (valheellinen
  lunastus). Jos haluat vastaanottajan palaavan, anna ilmeen vastata
  todellisuutta.
- **Värit ovat opittuja kulttuurisia koodeja, eivät universaaleja.** Sama väri
  tarkoittaa eri asioita eri yleisöille ja kulttuureissa (esim. arvokkuus,
  energisyys, raha, intohimo ovat kaikki kulttuurisesti opittuja kytköksiä).
  Valitse värit sen mukaan, mitä ne merkitsevät juuri kohdeheimolle.
- **Typografia viestii ennen sanoja.** Päätteetön, jämäkkä kirjasin pysäyttää ja
  viestii itsevarmuutta; päätteellinen kirjasin helpottaa lukemista pitkässä
  tekstissä. Oma, tunnistettava kirjaintyyli on vahva erottautuja, koska sitä
  toistetaan eniten.
- **Tyhjä tila on aktiivinen valinta.** Se ei ole täytettävää tilaa. Mitä
  arvokkaampi ja itsevarmempi mielikuva, sitä enemmän tyhjää tilaa — "minun ei
  tarvitse kertoa kaikkea, kerron vain tämän". Tila ympärillä nostaa kohteen
  arvoa (vrt. esine museossa vs. kadulla).
- **Aistittu panostus nostaa koettua arvoa.** Tuotannon laatu (kuva, video,
  materiaali) viestii uskottavuutta ja arvoa ennen kuin sisältöä on edes luettu.
  Huoliteltu ilme itsessään on argumentti.

---

## 8. Ääni — verbaaliset rakennuspalikat

- **Arkkityypit ohjaavat äänensävyä.** Persoona-arkkityyppi (esim. kapinallinen,
  huolehtija, uudistaja, tavallisen ihmisen ääni) määrää, miten sama asia
  sanotaan — sivistyssanoin vai puhekielellä, haastaen vai rauhoittaen.
  Verbaalisen ja visuaalisen viestinnän on kerrottava samaa ydinviestiä.
- **Kolmen rytmi jää mieleen.** Kolme iskua, kolme tavua, kolme huippuhetkeä
  toimivat muistin kannalta erityisen hyvin. Hyödynnä sloganeissa, puheissa ja
  ääniviestinnässä.
- **Ääni ja rytmi ovat brändiä siinä missä kuvakin.** Tunnistettava sanonta,
  äänensävy tai toistuva rakenne rakentaa muistijälkeä myös ilman kuvaa.
- **Kulttuurinen relevanssi.** Samastuttava, tunnistettava hahmo tai puhetapa
  osuu, vaikkei se olisi kirjaimellisesti totta koko yleisöstä. Puhu
  vastaanottajan maailmasta käsin, hänen esimerkeillään.

---

## 9. Dimensiot ja panostuksen järjestys

### Aloitusviisikko — mihin panostaa ensin
Kun brändiä rakennetaan, keskity tähän järjestykseen:
1. **Ydin** — kristallinkirkas ja kaikkien tiedossa.
2. **Arvolupaus** — järkeen vetoava, hyötyperusteinen versio ytimestä.
3. **Positiointi** — suhde todelliseen kilpailijaan ja ympäröivään.
4. **Visuaaliset dimensiot** — ilmeen perusakselit.
5. **Verbaaliset dimensiot** — äänen perusakselit.

### Dimensiot (ilmeen ja äänen perusakselit)
Määrittele brändi akseleilla, jotta tiedät kumman perässä olet joka valinnassa:
- Visuaalinen: pehmeä ↔ terävä (muotokieli), monokromaattinen ↔ värikäs,
  hillitty ↔ huomiota huutava.
- Verbaalinen: vakava ↔ leikkisä, muodollinen ↔ puhekielinen. Voit tarkentaa
  niin syvälle kuin haluat (esim. jos leikkisä → hauska / sarkastinen /
  ilkikurinen).
Dimensiot pitävät ilmeen ja äänen johdonmukaisena ja tunnistettavana.

### Brändikirja työkaluna, ei kahleena
Kirjatut linjaukset vapauttavat luovuutta, kun perusasioita ei tarvitse miettiä
joka kerta alusta. Ne eivät saa olla käsiraudat ("ei voida tehdä, koska ohje
kieltää"), vaan viitekehys, josta katsotaan miten asia menisi tässäkin
tapauksessa.

---

## 10. Viesti, budjetti ja pääoma

- **Näkyvyys vaatii panostusta.** Hyväkään viesti ei kuulu kakofoniassa ilman
  toistoa ja resurssia. Orgaanisen kasvun puute ei tarkoita että viesti on
  huono — media ei vain toimi niin.
- **Panostus heikkoon ytimeen on vaarallista.** Resurssi kannattaa vasta kun
  ydin on mietitty. Kirkkaasta ytimestä saa loputtomasti eri muotoisia viestejä
  eri yleisöille punainen lanka säilyttäen.
- **Rakenna pääomaa, älä vain hetkeä.** Pelkät taktiset iskut ("äänestä nyt",
  "toisin kuin vastustaja") tuottavat hetken, mutteivät kasvata kestävää
  brändipääomaa. Myynnin/äänen hetki on putken viimeinen osa — sitä ennen on
  pitänyt rakentaa tunne, tarve ja tunnettuus. Pitkä peli kantaa vaalista
  toiseen.
- **Kulttuurinen este.** Itsestä ääneen pitäminen ja "myyminen" tuntuu monesta
  vaivaannuttavalta. Silti: ihmisten on tunnettava sinut voidakseen valita
  sinut. Näkyvyys ei ole tuputtamista vaan edellytys.

---

## 11. Luova prosessi (ideoinnin ja työpajan moottori)

- **Poista häpeää, älä lisää rohkeutta.** Kun häpeä väistyy, rohkeus seuraa
  itsestään. Parhaat oivallukset syntyvät "nolon" kynnyksen takaa.
- **Ole huoneen tyhmin — kysy tyhmiä kysymyksiä.** Kysymykset, joita ei kehtaa
  kysyä, avaavat sen, mitä kukaan muu ei ole uskaltanut avata.
- **Nolous on signaali.** Jos idea tuntuu keskeneräiseltä ja kiusalliselta, se
  voi olla merkki läpimurrosta. Parhaat ideat kulkevat lähellä noloa.
- **Ideoi määrällä, älä rakastu ensimmäiseen.** Ensin tulee paljon huonoja —
  vasta niiden jälkeen päästään ytimeen. Vaihda tulokulmaa ("miksi tämä olisi
  merkityksellistä?").
- **Heitä huonot ideat ääneen.** Se murtaa jään, jolloin muutkin uskaltavat.
  Kuonan seasta löytyvät parhaat. Validaatio ei ole "hyvä idea" -kommentti —
  huono idea + briljantti toteutus voi voittaa.
- **Faktat ovat default, tunne on ytimessä.** Ihminen kertoo mieluummin mitä
  tekee kuin kuka on, koska faktoille on yhteinen kieli ja tunteille ei. Hyvä
  työ kaivautuu faktojen alta tunteeseen.

---

## 12. Yleisimmät virheet

1. Puhua ehdokkaasta/ohjelmasta sen sijaan että puhuisi äänestäjästä ja hyödystä.
2. Sekoittaa brändi (tunne) ja brändäys (työkalut) — ja aloittaa tunnuksista
   ytimen sijaan.
3. Määritellä kohteeksi "kaikki" tai nojata demografiaan aidon heimon sijaan.
4. Yrittää miellyttää kaikkia → viesti vesittyy, ei uskalleta ottaa kantaa.
5. Hajauttaa viestiä ja uudistautua jatkuvasti (itsevarmuuden puute).
6. Etääntyä ytimestä vauhtisokeudessa.
7. Leimata tunne ja mielikuva "hötöksi" ja jättää panostamatta niihin.
8. Panostaa resurssi heikkoon, miettimättömään ytimeen.
9. Rakentaa valheellinen mielikuva (ilme ei vastaa todellisuutta).
10. Viestiä arvoja, jotka eivät ohjaa tekoja (uskottavuusriski).
11. Rakastua ensimmäiseen ideaan ja karsia rohkeat aihiot liian aikaisin.
12. Olla johdonmukaisuudeton ilmeessä tai äänessä → luottamus rapautuu.
