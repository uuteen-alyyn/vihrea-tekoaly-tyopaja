# Poliittinen brändikonsultti — Claude-skill

Brändin, imagon ja pääviestin asiantuntemusta poliittiseen vaalikampanjaan.
Auttaa ehdokasta tai puoluetta kirkastamaan ydinviestinsä, erottumaan
kilpailijoista, tunnistamaan oikean kohdeyleisön ja rakentamaan haluttua
mielikuvaa.

## Milloin skilli aktivoituu

Kun kehitetään pääviestiä tai kärkiteemoja, mietitään miten jokin aihe kannattaa
kehystää, tai arvioidaan tukeeko kampanjamateriaali (slogan, some-postaus, puhe,
kuva) haluttua brändiä. Toimii suomeksi, mille tahansa ehdokkaalle tai
puolueelle.

Skilli tarjoaa periaatteet ja näkökulmat — se ei tuota valmista sisältöä
(sloganeja, postauksia, julisteita), vaan ohjaa strategian tasolla ja arvioi,
tukeeko jokin haluttua mielikuvaa.

## Asennus

### Claude Code — henkilökohtainen (kaikki projektit)
Kopioi kansio `poliittinen-brandikonsultti` tänne:
```
~/.claude/skills/poliittinen-brandikonsultti/
```
Lopputulos: `~/.claude/skills/poliittinen-brandikonsultti/SKILL.md`

### Claude Code — projektikohtainen (vain yksi projekti)
Kopioi sama kansio projektisi hakemistoon:
```
.claude/skills/poliittinen-brandikonsultti/
```

### claude.ai
Lataa `poliittinen-brandikonsultti.zip` Clauden asetuksista:
**Settings → Capabilities → Skills → Upload skill.**

Asennuksen jälkeen skilli aktivoituu automaattisesti aiheeseen sopivissa
keskusteluissa. Claude Codessa sen voi kutsua myös suoraan komennolla
`/poliittinen-brandikonsultti`.

## Rakenne

```
poliittinen-brandikonsultti/
├── SKILL.md              # ydin: periaatteet + soveltamisohjeet (ladataan kun skilli laukeaa)
├── README.md             # tämä tiedosto
└── references/
    └── periaatteet.md    # laajempi tietopohja (ladataan vain tarvittaessa)
```

## Käyttö

Skilli on yleiskäyttöinen: se ei ole sidottu yhteen puolueeseen eikä yhteen
työnkulkuun. Muokkaa vapaasti omaan käyttöösi. Voit soveltaa sitä esimerkiksi:

- **Pääviestin kirkastaminen** — "auta kirkastamaan ehdokkaan ydinviesti"
- **Erottautuminen** — "miten erotun oman listan muista ehdokkaista?"
- **Kehystäminen** — "millä kehyksellä tätä aihetta kannattaa lähestyä?"
- **Materiaalin arviointi** — "tukeeko tämä some-postaus haluttua brändiä?"
