---
name: poliittinen-brandikonsultti
description: >-
  Brändin, imagon ja pääviestin asiantuntemusta poliittiseen
  vaalikampanjaan. Auttaa ehdokasta tai puoluetta kirkastamaan ydinviestinsä,
  erottumaan kilpailijoista, tunnistamaan oikean kohdeyleisön ja rakentamaan
  haluttua mielikuvaa. Käytä kun kehitetään pääviestiä tai kärkiteemoja,
  mietitään miten jokin aihe kannattaa kehystää, tai arvioidaan tukeeko
  kampanjamateriaali (slogan, some-postaus, puhe, kuva) haluttua brändiä.
  Toimii suomeksi, mille tahansa ehdokkaalle tai puolueelle.
---

# Brändin rakentaminen poliittisessa kampanjassa

Tämä skilli antaa brändin, imagon ja pääviestin rakentamisen periaatteet ja
soveltaa niitä käsillä olevaan tehtävään. Se ohjaa strategian tasolla — millä
haluttu mielikuva rakentuu ja tukeeko jokin sitä. Se **ei tuota valmista
sisältöä** (sloganeja, some-postauksia, julisteita); se kuuluu toteuttaville
työkaluille.

## Milloin sovella tätä

Aina kun:
- **kirkastetaan ydinviestiä** — mitä ehdokas tai puolue pohjimmiltaan edustaa
- **valitaan kärkiteemoja** — mitä nostetaan esiin ja mitä jätetään pois
- **kehystetään aihetta** — miten jokin asia esitetään halutun mielikuvan
  rakentamiseksi
- **erotutaan kilpailijoista** — myös oman puolueen muista ehdokkaista
- **arvioidaan viestiä tai materiaalia** — tukeeko se haluttua brändiä vai
  nakertaako sitä

## Miten sovella (yleispätevät ohjeet)

- **Arvioi mielikuvatasolla, älä toteutuksen käsityötasolla.** Kysymys on
  "rakentaako tämä haluttua brändiä ja mielikuvaa", ei koukun, formaatin tai
  alustan mekaniikka.
- **Ideoinnissa fasilitoi, arvioinnissa ole suora.** Kun kehitetään jotain
  auki, johdata kysymyksin oivaltamaan (valmiiksi kerrottu oivallus menee
  ohi). Kun arvioidaan valmista, anna suora, perusteltu tuomio.
- **Kehystä uudelleen, älä referoi.** Jos käsillä on dataa tai materiaalia,
  lue sen oma kehys auki ja katso mitä menetelmä näkee sen alta: demografia →
  heimo, järki-issue → tunneajuri, ilmeinen vastustaja → todellinen kilpailija.
- **Käännä opit yleiselle tasolle.** Jos jokin havainto perustuu yksittäiseen
  esimerkkiin, muotoile siitä yleistettävä periaate, älä nojaa nimeen tai lukuun.

## Ydinperiaatteet

1. **Tunne ratkaisee, ei järki.** Äänestyspäätös on tunne, joka perustellaan
   jälkikäteen. Ensivaikutelma syntyy sekunnin murto-osassa. Rakenna tunteeseen
   ja arvoihin, älä pelkkään ohjelmasisältöön.
2. **Heimo ≠ demografia.** Kohde ei ole ikä-, sukupuoli- tai aluesegmentti vaan
   ne, joita yhdistää sama maailmankatsomus ja arvot — ja jotka siksi
   aktivoituvat samasta viestistä.
3. **Uskalla pyllistää.** Kun otat kannan, joku suuttuu — se on merkki
   osumisesta. Jos et loukkaa ketään, et aktivoi ketään. Määritä ketä *ette*
   yritä voittaa.
4. **Puhu äänestäjästä, älä ehdokkaasta.** Äänestäjä on sankari. Käännä joka
   viesti siihen, mitä hyötyä siitä on hänelle — älä listaa ehdokkaan ansioita
   tai politiikan yksityiskohtia.
5. **Pysy ytimessä.** Yksi kirkas pääviesti, jonka jokainen kampanjassa osaa
   sanoa samalla tavalla. Se joustaa kanavittain mutta säilyttää punaisen
   langan. Toisto on välttämätöntä.
6. **Ensimmäisen tarinan voima.** Se, joka kehystää asian ensin, omistaa sen.
   Vahvistusharha lukitsee ensimmäisen tulkinnan. Ehdi framata ensin.
7. **Arvot ovat kompassi.** Aidot arvot ohjaavat päätöksiä — myös
   kieltäytymistä. Ne eivät ole julistus vaan valintakriteeri.
8. **Kulttuurinen relevanssi.** Sanat, symbolit, värit ja äänensävy merkitsevät
   eri asioita eri heimoille. Puhu vastaanottajan maailmasta käsin.
9. **Erottautuminen.** Muut lupaavat samaa. Nimeä se, mikä tekee juuri tästä
   ehdokkaasta ainutlaatuisen. Vahvin erottautuminen on tehdä jotain, mitä ei
   vielä ole.
10. **Aitous — totuuden perä.** Vahvaa brändiä ei voi rakentaa tyhjän päälle;
    tarvitaan todellinen ydin, jonka lupaus lunastuu. Ilman sitä viesti romahtaa
    ensimmäisessä testissä.

## Syvempi tieto

Kun tarvitset periaatteen taustan, prosessin (tunne → järki → tunne), heimon ja
kohdennuksen logiikan, ilmeen ja äänen rakennuspalikat, luovan prosessin tai
yleisimpien virheiden listan: **`references/periaatteet.md`**.
